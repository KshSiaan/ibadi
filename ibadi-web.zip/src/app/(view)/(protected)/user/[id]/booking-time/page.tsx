"use client";

import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Plus,
  RefreshCw,
  Trash2,
  X,
} from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import { Suspense, use, useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useGetUserById } from "@/hooks/api/user/use-get-user-by-id";
import type { WorkSchedule } from "@/lib/api/types";
import { cn } from "@/lib/utils";

const DAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

function isoToTime(iso: string): string {
  const match = iso.match(/T(\d{2}:\d{2})/);
  return match ? match[1] : iso;
}

function timeToMinutes(time: string): number {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
}

function getWeekStart(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

function addDays(date: Date, days: number) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

function getAvailableDays(
  workSchedule: WorkSchedule[] | undefined,
  t: (key: string) => string,
): Set<string> {
  const available = new Set<string>();
  if (!workSchedule) return available;
  for (const entry of workSchedule) {
    if (entry.status) {
      available.add(t(dayMap[entry.day] ?? entry.day));
    }
  }
  return available;
}

function getDayTimeRange(
  workSchedule: WorkSchedule[] | undefined,
  dayAbbr: string,
): { start: string; end: string } | null {
  if (!workSchedule) return null;
  const entry = workSchedule.find((e) => e.day === dayAbbr && e.status);
  if (!entry) return null;
  return { start: isoToTime(entry.startTime), end: isoToTime(entry.endTime) };
}

function filterTimesInRange(
  range: { start: string; end: string } | null,
): string[] {
  // if (!range)
  return allTimeSlots;
  // const startMin = timeToMinutes(range.start);
  // const endMin = timeToMinutes(range.end);
  // return allTimeSlots.filter((t) => {
  //   const mins = timeToMinutes(t);
  //   return mins >= startMin && mins < endMin;
  // });
}

const allTimeSlots: string[] = [
  "06:00",
  "07:00",
  "08:00",
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "16:30",
  "17:00",
  "18:00",
  "19:00",
  "20:00",
  "21:00",
  "22:00",
  "23:00",
];

function addHours(time: string, hours: number): string {
  const [h, m] = time.split(":").map(Number);
  const totalMins = h * 60 + m + hours * 60;
  const newH = Math.floor(totalMins / 60) % 24;
  const newM = totalMins % 60;
  return `${String(newH).padStart(2, "0")}:${String(newM).padStart(2, "0")}`;
}

function TimeButton({
  time,
  selected,
  onClick,
}: {
  time: string;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded border px-2 py-1.5 text-xs font-medium transition-colors",
        selected
          ? "border-primary bg-primary text-white"
          : "border-gray-200 bg-white text-gray-700 hover:border-primary/50",
      )}
    >
      {time}
    </button>
  );
}

function TimeGrid({
  selectedTime,
  onSelect,
  availableTimes,
}: {
  selectedTime: string | null;
  onSelect: (t: string) => void;
  availableTimes: string[];
}) {
  return (
    <div className="grid grid-cols-3 gap-2 w-full">
      {availableTimes.map((time) => (
        <>
          <TimeButton
            key={time}
            time={time}
            selected={selectedTime === time}
            onClick={() => onSelect(time)}
          />
        </>
      ))}
    </div>
  );
}

function DayPanel({
  day,
  duration,
  selectedTime,
  availableTimes,
  onDurationChange,
  onTimeSelect,
  onSave,
  onClose,
}: {
  day: string;
  duration: number;
  selectedTime: string | null;
  availableTimes: string[];
  onDurationChange: (d: number) => void;
  onTimeSelect: (t: string) => void;
  onSave: () => void;
  onClose: () => void;
}) {
  const t = useTranslations("BookingTime");
  const endTime = selectedTime ? addHours(selectedTime, duration) : null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#f5f5f5] lg:px-[34%]">
      <div className="flex items-center justify-between bg-white px-5 py-4">
        <h2 className="text-base font-bold text-gray-800">{day}</h2>
        <button type="button" onClick={onClose} className="text-gray-500">
          <X className="size-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-5">
        <p className="mb-4 text-sm font-semibold text-gray-800">
          {t("duration")}{" "}
          <span className="font-bold text-primary">{duration}h</span>
        </p>
        <div className="mb-8">
          <Slider
            min={1}
            max={8}
            step={1}
            value={[duration]}
            onValueChange={([v]) => onDurationChange(v)}
          />
        </div>

        <p className="mb-4 text-sm font-semibold text-gray-800">
          {t("startTime")}
        </p>
        <TimeGrid
          selectedTime={selectedTime}
          onSelect={onTimeSelect}
          availableTimes={availableTimes}
        />
      </div>

      <div className="bg-white px-5 py-4">
        <button
          type="button"
          onClick={onSave}
          disabled={!selectedTime}
          className="w-full rounded-xl bg-primary py-3.5 text-sm font-semibold text-white disabled:opacity-40"
        >
          {selectedTime && endTime
            ? t("saveTime", { start: selectedTime, end: endTime })
            : t("selectStartTime")}
        </button>
      </div>
    </div>
  );
}

const dayMap: Record<string, string> = {
  Mon: "monday",
  Tue: "tuesday",
  Wed: "wednesday",
  Thu: "thursday",
  Fri: "friday",
  Sat: "saturday",
  Sun: "sunday",
};

type DaySlot = { time: string; duration: number };

function WeeklyLoadingState() {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 px-5 py-8 text-center">
      <RefreshCw className="size-6 animate-spin text-primary" />
      <p className="text-sm font-medium text-gray-600">
        Loading weekly availability...
      </p>
    </div>
  );
}

function WeeklyErrorState({
  error,
  onRetry,
}: {
  error?: { message?: string } | null;
  onRetry: () => void;
}) {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-4 px-5 py-8 text-center">
      <p className="text-base font-semibold text-gray-800">
        Failed to load weekly availability.
      </p>
      <p className="text-sm text-gray-500">
        {error?.message || "Please try again."}
      </p>
      <Button type="button" onClick={onRetry}>
        Retry
      </Button>
    </div>
  );
}

function WeeklyEmptyState() {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center gap-3 px-5 py-8 text-center">
      <p className="text-base font-semibold text-gray-800">
        No weekly slots available
      </p>
      <p className="max-w-xs text-sm text-gray-500">
        This provider does not have any weekly availability set yet.
      </p>
    </div>
  );
}

function WeeklyView({
  providerId,
  pricePerHour,
  workSchedule,
  onClose,
  onFrequencyToggle,
  isLoading,
  isError,
  error,
  onRetry,
}: {
  providerId: string;
  pricePerHour: number;
  workSchedule: WorkSchedule[] | undefined;
  onClose: () => void;
  onFrequencyToggle: () => void;
  isLoading?: boolean;
  isError?: boolean;
  error?: { message?: string } | null;
  onRetry?: () => void;
}) {
  const t = useTranslations("BookingTime");
  const availableDays = getAvailableDays(workSchedule, t);
  const [slots, setSlots] = useState<Record<string, DaySlot>>({});
  const [activeDay, setActiveDay] = useState<string | null>(null);
  const [panelDuration, setPanelDuration] = useState(2);
  const [panelTime, setPanelTime] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="flex flex-col bg-background lg:px-[34%] px-4">
        <div className="flex items-center justify-between px-5 py-4">
          <button
            type="button"
            onClick={onFrequencyToggle}
            className="flex items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm"
          >
            <RefreshCw className="size-4 text-primary" />
            {t("weekly")}
            <ChevronDown className="size-4 text-gray-400" />
          </button>
          <button type="button" onClick={onClose} className="text-gray-500">
            <X className="size-5" />
          </button>
        </div>
        <WeeklyLoadingState />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex flex-col bg-background lg:px-[34%] px-4">
        <div className="flex items-center justify-between px-5 py-4">
          <button
            type="button"
            onClick={onFrequencyToggle}
            className="flex items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm"
          >
            <RefreshCw className="size-4 text-primary" />
            {t("weekly")}
            <ChevronDown className="size-4 text-gray-400" />
          </button>
          <button type="button" onClick={onClose} className="text-gray-500">
            <X className="size-5" />
          </button>
        </div>
        <WeeklyErrorState error={error} onRetry={onRetry ?? (() => {})} />
      </div>
    );
  }

  // Reverse map: translated day name → day abbreviation (e.g. "Mon")
  const translatedToAbbr = Object.fromEntries(
    Object.entries(dayMap).map(([abbr, key]) => [t(key), abbr]),
  );

  // Only show days the provider is available for
  const days = [
    t("monday"),
    t("tuesday"),
    t("wednesday"),
    t("thursday"),
    t("friday"),
    t("saturday"),
    t("sunday"),
  ].filter((day) => availableDays.has(day));

  if (!workSchedule || workSchedule.length === 0 || days.length === 0) {
    return (
      <div className="flex flex-col bg-background lg:px-[34%] px-4">
        <div className="flex items-center justify-between px-5 py-4">
          <button
            type="button"
            onClick={onFrequencyToggle}
            className="flex items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm"
          >
            <RefreshCw className="size-4 text-primary" />
            {t("weekly")}
            <ChevronDown className="size-4 text-gray-400" />
          </button>
          <button type="button" onClick={onClose} className="text-gray-500">
            <X className="size-5" />
          </button>
        </div>
        <WeeklyEmptyState />
      </div>
    );
  }

  function openDay(day: string) {
    const existing = slots[day];

    const translatedToAbbr = Object.fromEntries(
      Object.entries(dayMap).map(([abbr, key]) => [t(key), abbr]),
    );

    const range = getDayTimeRange(workSchedule, translatedToAbbr[day]);

    const available = filterTimesInRange(range);

    setPanelDuration(existing?.duration ?? 2);
    setPanelTime(existing?.time ?? available[0] ?? null);
    setActiveDay(day);
  }

  function saveDay() {
    if (!activeDay || !panelTime) return;
    setSlots((s) => ({
      ...s,
      [activeDay]: { time: panelTime, duration: panelDuration },
    }));
    setActiveDay(null);
  }

  function removeDay(day: string) {
    setSlots((s) => {
      const next = { ...s };
      delete next[day];
      return next;
    });
  }

  const hasSlots = Object.keys(slots).length > 0;

  const confirmHref = hasSlots
    ? `/user/${providerId}/booking-time/confirm?frequency=weekly&slots=${encodeURIComponent(
        JSON.stringify(slots),
      )}&providerId=${providerId}&pricePerHour=${pricePerHour}`
    : "#";

  return (
    <div className="flex flex-col bg-background lg:px-[34%] px-4">
      <div className="flex items-center justify-between px-5 py-4">
        <button
          type="button"
          onClick={onFrequencyToggle}
          className="flex items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm"
        >
          <RefreshCw className="size-4 text-primary" />
          {t("weekly")}
          <ChevronDown className="size-4 text-gray-400" />
        </button>
        <button type="button" onClick={onClose} className="text-gray-500">
          <X className="size-5" />
        </button>
      </div>

      <div className="flex flex-1 flex-col gap-2 px-5">
        {days.map((day) => {
          const slot = slots[day];
          if (slot) {
            return (
              <div
                key={day}
                className="flex items-center justify-between rounded-lg border border-primary/30 bg-primary/5 px-4 py-3"
              >
                <span className="text-sm font-semibold text-gray-800">
                  {day}
                </span>
                <div className="flex items-center gap-3">
                  <span className="text-sm text-gray-600">
                    {slot.time} - {addHours(slot.time, slot.duration)}
                  </span>
                  <button
                    type="button"
                    onClick={() => removeDay(day)}
                    className="text-gray-400 hover:text-red-500"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
              </div>
            );
          }
          // Day is available but no slot picked yet — show add button
          return (
            <button
              key={day}
              type="button"
              onClick={() => openDay(day)}
              className="flex items-center justify-between rounded-lg border border-gray-200 bg-white px-4 py-3 hover:border-primary/30"
            >
              <span className="text-sm text-gray-600">{day}</span>
              <Plus className="size-4 text-gray-400" />
            </button>
          );
        })}
      </div>

      <div className="px-5 py-5 mt-24">
        <Button type="button" className="w-full" disabled={!hasSlots} asChild>
          <Link href={confirmHref}>
            {hasSlots
              ? t("saveDays", { count: Object.keys(slots).length })
              : t("selectAtLeastOneDay")}
          </Link>
        </Button>
      </div>

      {activeDay && (
        <DayPanel
          day={activeDay}
          duration={panelDuration}
          selectedTime={panelTime}
          availableTimes={filterTimesInRange(
            getDayTimeRange(workSchedule, translatedToAbbr[activeDay]),
          )}
          onDurationChange={setPanelDuration}
          onTimeSelect={setPanelTime}
          onSave={saveDay}
          onClose={() => setActiveDay(null)}
        />
      )}
    </div>
  );
}

function OnceView({
  providerId,
  pricePerHour,
  workSchedule,
  onClose,
  onFrequencyToggle,
}: {
  providerId: string;
  pricePerHour: number;
  workSchedule: WorkSchedule[] | undefined;
  onClose: () => void;
  onFrequencyToggle: () => void;
}) {
  const t = useTranslations("BookingTime");
  const [duration, setDuration] = useState(2);
  const [weekOffset, setWeekOffset] = useState(0);
  const [showMonthPicker, setShowMonthPicker] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const weekDays = useMemo(() => {
    const monday = getWeekStart(new Date());
    const weekMonday = addDays(monday, weekOffset * 7);

    return Array.from({ length: 7 }, (_, i) => {
      const d = addDays(weekMonday, i);

      return {
        short: DAY_LABELS[d.getDay()],
        date: d.getDate(),
        month: d.getMonth(),
        year: d.getFullYear(),
        full: d,
      };
    });
  }, [weekOffset]);
  // Get available times for the currently selected day
  const selectedDayAbbr = DAY_LABELS[selectedDate.getDay()];
  const dayRange = getDayTimeRange(workSchedule, selectedDayAbbr);
  const availableTimes = filterTimesInRange(dayRange);

  // Auto-select first available time when available times change
  useEffect(() => {
    if (availableTimes.length > 0) {
      const firstAvailableTime = availableTimes[0];
      if (
        firstAvailableTime &&
        (selectedTime === null || !availableTimes.includes(selectedTime))
      ) {
        setSelectedTime(firstAvailableTime);
      }
      return;
    }

    setSelectedTime(null);
  }, [availableTimes, selectedTime]);

  const endTime = selectedTime ? addHours(selectedTime, duration) : null;
  // const totalPrice = duration * pricePerHour;
  // const day = DAY_LABELS[selectedDate.getDay()].toLowerCase();
  const confirmHref = selectedTime
    ? `/user/${providerId}/booking-time/confirm?${new URLSearchParams({
        frequency: "one_time",
        day: String(selectedDate.getDate()),
        month: String(selectedDate.getMonth()),
        year: String(selectedDate.getFullYear()),
        time: selectedTime,
        duration: String(duration),
        providerId,
        pricePerHour: String(pricePerHour),
      }).toString()}`
    : "#";

  // Filter week days to only show provider-available days
  const availableDayAbbrs = new Set<string>(
    (workSchedule ?? []).filter((e) => e.status).map((e) => e.day),
  );
  const visibleWeekDays = weekDays.filter((d) =>
    availableDayAbbrs.has(d.short),
  );

  return (
    <div className="flex flex-col lg:px-[34%] px-4  ">
      <div className="flex items-center justify-between py-4">
        <button
          type="button"
          onClick={onFrequencyToggle}
          className="flex items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm"
        >
          <span className="text-base">🎯</span>
          {t("justOnce")}
          <ChevronDown className="size-4 text-gray-400" />
        </button>
        <button type="button" onClick={onClose} className="text-gray-500">
          <X className="size-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto py-2">
        <p className="mb-4 text-sm font-semibold text-gray-800">
          {t("duration")}{" "}
          <span className="font-bold text-primary">{duration}h</span>
        </p>
        <div className="mb-8">
          <Slider
            min={1}
            max={8}
            step={1}
            value={[duration]}
            onValueChange={([v]) => setDuration(v)}
          />
        </div>

        <div className="mb-6">
          <div className="mb-3 flex items-center justify-between">
            <div className="mb-3 flex items-center justify-between w-full">
              <div className="flex items-center gap-2">
                {/** biome-ignore lint/a11y/useButtonType: This previous-week control is a button and should not submit a form. */}
                <button onClick={() => setWeekOffset((o) => o - 1)}>
                  <ChevronLeft className="size-4" />
                </button>

                <p className="text-sm font-semibold">
                  {MONTH_NAMES[weekDays[0].month]} {weekDays[0].year}
                </p>

                <Button onClick={() => setWeekOffset((o) => o + 1)}>
                  <ChevronRight className="size-4" />
                </Button>
              </div>

              <Button
                size="sm"
                className="rounded-full"
                onClick={() => setShowMonthPicker((v) => !v)}
              >
                {t("showMonth")}
              </Button>
            </div>
          </div>
          {showMonthPicker && (
            <div className="mb-4 grid grid-cols-4 gap-2">
              {MONTH_NAMES.map((name, idx) => (
                <button
                  type="button"
                  className={cn(
                    "rounded-lg py-1.5 text-xs font-medium transition-colors",
                    weekDays[0].month === idx
                      ? "bg-primary text-white"
                      : "bg-gray-50 text-gray-600 hover:bg-gray-100",
                  )}
                  key={name}
                  onClick={() => {
                    const firstDay = new Date(new Date().getFullYear(), idx, 1);
                    const monday = getWeekStart(firstDay);
                    const thisMonday = getWeekStart(new Date());

                    const diff = Math.round(
                      (monday.getTime() - thisMonday.getTime()) /
                        (1000 * 60 * 60 * 24 * 7),
                    );

                    setWeekOffset(diff);
                    setShowMonthPicker(false);
                  }}
                >
                  {name.slice(0, 3)}
                </button>
              ))}
            </div>
          )}
          <div className="flex gap-1.5">
            {visibleWeekDays.map((d) => (
              <button
                type="button"
                key={d.date}
                onClick={() => setSelectedDate(d.full)}
                className={cn(
                  "flex flex-1 flex-col items-center rounded-xl py-2 text-xs font-medium transition-colors",
                  selectedDate.toDateString() === d.full.toDateString()
                    ? "bg-primary text-white"
                    : "bg-white text-gray-600",
                )}
              >
                <span className="text-[10px] font-normal">{d.short}</span>
                <span className="text-sm font-bold">{d.date}</span>
              </button>
            ))}
          </div>
        </div>

        {/* {availableTimes.length > 0 ? ( */}
        <>
          <p className="mb-4 text-sm font-semibold text-gray-800">
            {t("startTime")}
          </p>
          <TimeGrid
            selectedTime={selectedTime}
            onSelect={setSelectedTime}
            availableTimes={availableTimes}
          />
        </>
        {/* ) : (
        //   <p className="text-sm text-gray-400">{t("notAvailable")}</p>
        // ) */}
      </div>

      <div className="py-5 mt-24">
        <Button disabled={!selectedTime} className="w-full" asChild>
          <Link href={confirmHref}>
            {selectedTime && endTime
              ? t("saveTime", { start: selectedTime, end: endTime })
              : t("selectStartTime")}
          </Link>
        </Button>
      </div>
    </div>
  );
}

function BookingTimePage({ id }: { id: string }) {
  const router = useRouter();
  const params = useSearchParams();
  const freq = params.get("frequency") as "weekly" | "one_time" | null;
  const pricePerHour = Number(params.get("pricePerHour") ?? 10);
  const {
    data: provider,
    isLoading,
    isError,
    error,
    refetch,
  } = useGetUserById(id);
  const [frequency, setFrequency] = useState<"weekly" | "one_time">(
    freq === "one_time" ? "one_time" : "weekly",
  );

  function toggleFrequency() {
    setFrequency((f) => (f === "weekly" ? "one_time" : "weekly"));
  }

  if (frequency === "weekly") {
    return (
      <WeeklyView
        providerId={id}
        pricePerHour={pricePerHour}
        workSchedule={provider?.workSchedule}
        onClose={() => router.back()}
        onFrequencyToggle={toggleFrequency}
        isLoading={isLoading}
        isError={isError}
        error={error}
        onRetry={() => refetch()}
      />
    );
  }

  return (
    <OnceView
      providerId={id}
      pricePerHour={pricePerHour}
      workSchedule={provider?.workSchedule}
      onClose={() => router.back()}
      onFrequencyToggle={toggleFrequency}
    />
  );
}

export default function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return (
    <Suspense>
      <BookingTimePage id={id} />
    </Suspense>
  );
}
